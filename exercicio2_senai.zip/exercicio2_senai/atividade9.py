n = int(input("Digite um número: "))

# Exibe a tabuada do número digitado
print("Tabuada do número", n)
for i in range(1, 101):
    print(n, "x", i, "=", n*i)
