n = int(input("Digite um número inteiro: "))

# Verifica se um número é perfeito
def is_perfect(number):
    divisors_sum = sum([i for i in range(1, number) if number % i == 0])
    return divisors_sum == number

# Exibe os números perfeitos menores ou iguais a n
print("Os números perfeitos menores ou iguais a", n, "são:")
for i in range(1, n+1):
    if is_perfect(i):
        print(i)
