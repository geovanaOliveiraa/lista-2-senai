n = int(input("Digite um número inteiro: "))

# Verifica se um número é primo
def eh_primo(num):
    if num < 2:
        return False
    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:
            return False
    return True

# Encontra e exibe todos os fatores primos de n
fatores_primos = []
for i in range(2, n+1):
    while n % i == 0 and eh_primo(i):
        fatores_primos.append(i)
        n //= i

if len(fatores_primos) == 0:
    print("O número", n, "não possui fatores primos.")
else:
    print("Os fatores primos de", n, "são:", fatores_primos)

