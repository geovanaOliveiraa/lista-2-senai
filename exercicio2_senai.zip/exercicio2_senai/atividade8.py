n = int(input("Digite um número inteiro: "))

# Converte um número decimal para binário
def decimal_to_binary(number):
    if number == 0:
        return "0b0"
    binary_digits = []
    while number > 0:
        binary_digits.append(str(number % 2))
        number //= 2
    binary_digits.reverse()
    return "0b" + "".join(binary_digits)

# Exibe o número em binário
binary = decimal_to_binary(n)
print("O número", n, "em binário é:", binary)
