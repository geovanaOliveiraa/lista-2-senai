n = int(input("Digite um número inteiro: "))

# Exibe todos os múltiplos de n menores que 100
print("Múltiplos de", n, "menores que 100:")
for i in range(1, 100):
    if i % n == 0:
        print(i)
