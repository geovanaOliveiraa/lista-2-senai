n = int(input("Digite um número inteiro: "))

# Calcula a sequência de Fibonacci até o n-ésimo termo
fibonacci = [0, 1]
while len(fibonacci) < n:
    fibonacci.append(fibonacci[-1] + fibonacci[-2])

# Exibe a sequência de Fibonacci
print("A sequência de Fibonacci até o", n, "-ésimo termo é:")
for i in range(n):
    print(fibonacci[i])
