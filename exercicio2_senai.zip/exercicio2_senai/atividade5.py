n = int(input("Digite um número inteiro: "))

# Calcula o fatorial de n
fatorial = 1
for i in range(1, n+1):
    fatorial *= i

# Exibe o resultado
print("O fatorial de", n, "é", fatorial)
